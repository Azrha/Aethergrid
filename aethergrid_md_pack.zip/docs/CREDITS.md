# Credits

List every external asset source used in the repo.

For each item include:
- Name
- Author
- License
- Source link
- Files used

## Example entry
- Name:
- Author:
- License:
- Source:
- Files:
